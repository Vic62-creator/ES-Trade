# ES-Trade Deployment Guide

Upload to GitHub, connect to Vercel.